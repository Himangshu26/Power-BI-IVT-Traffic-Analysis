# 📊 IVT Traffic Analysis Dashboard (Power BI Project)

## 🧠 Overview
This Power BI project analyzes ad traffic data to detect **Invalid Traffic (IVT)** patterns across multiple apps.  
The dataset includes metrics like unique devices (IDFAs), IPs, User-Agents, ad requests, and impressions.  
By visualizing these metrics, the dashboard helps identify **why some apps were flagged as IVT earlier** while others remained valid.

---

## 📂 Project Structure

```
IVT_Traffic_Analysis_Repository/
│
├── Data/
│   ├── Data Analytics Assignment - Valid 1.csv
│   ├── Data Analytics Assignment - Valid 2.csv
│   ├── Data Analytics Assignment - Valid 3.csv
│   ├── Data Analytics Assignment - Invalid 1.csv
│   ├── Data Analytics Assignment - Invalid 2.csv
│   ├── Data Analytics Assignment - Invalid 3.csv
│
├── PowerBI_Dashboard/
│   ├── IVT_Dashboard_Theme.json
│   └── IVT_Traffic_Analysis.pbix  ← (Save your Power BI file here)
│
└── README.md
```

---

## ⚙️ Steps to Build the Power BI Dashboard

### **1️⃣ Load Data**
1. Open **Power BI Desktop**.
2. Click **Home → Get Data → Text/CSV**.
3. Import all six CSV files (Valid + Invalid apps).
4. Load them into Power BI.

---

### **2️⃣ Combine the Data**
1. Go to **Transform Data → Power Query Editor**.
2. Use **Append Queries as New**.
3. Select all six tables → name the combined table `Master_IVT_Dataset`.
4. Click **Close & Apply**.

---

### **3️⃣ Create Calculated Columns**
Go to **Modeling → New Column**, and paste the following DAX formulas:

```DAX
Requests_per_IDFA = DIVIDE('Master_IVT_Dataset'[total_requests], 'Master_IVT_Dataset'[unique_idfas], 0)

Impressions_per_IDFA = DIVIDE('Master_IVT_Dataset'[impressions], 'Master_IVT_Dataset'[unique_idfas], 0)

IDFA_IP_Ratio = DIVIDE('Master_IVT_Dataset'[unique_idfas], 'Master_IVT_Dataset'[unique_ips], 0)

IDFA_UA_Ratio = DIVIDE('Master_IVT_Dataset'[unique_idfas], 'Master_IVT_Dataset'[unique_uas], 0)

IVT_Status =
VAR RequestsPerIDFA = DIVIDE('Master_IVT_Dataset'[total_requests], 'Master_IVT_Dataset'[unique_idfas], 0)
VAR IDFA_IP = DIVIDE('Master_IVT_Dataset'[unique_idfas], 'Master_IVT_Dataset'[unique_ips], 0)
VAR IDFA_UA = DIVIDE('Master_IVT_Dataset'[unique_idfas], 'Master_IVT_Dataset'[unique_uas], 0)
VAR ImpressionsPerIDFA = DIVIDE('Master_IVT_Dataset'[impressions], 'Master_IVT_Dataset'[unique_idfas], 0)
RETURN
IF(
    (
        (RequestsPerIDFA > 1000 && IDFA_UA > 3) || 
        (ImpressionsPerIDFA < 0.7 && IDFA_IP > 2)
    ),
    "IVT",
    "Valid"
)
```

---

### **4️⃣ Apply Custom Theme**
1. Go to **View → Themes → Browse for themes**.
2. Select `IVT_Dashboard_Theme.json` from the `PowerBI_Dashboard` folder.

---

### **5️⃣ Create Dashboard Visuals**
| Visual | Fields | Purpose |
|--------|---------|----------|
| **Card** | Total Requests, Unique IDFAs, IVT Count | KPIs overview |
| **Pie Chart** | IVT_Status | Compare IVT vs Valid traffic |
| **Line Chart** | Date → IVT Ratio | Show IVT trend over time |
| **Bar Chart** | App Name → Average IDFA/UA Ratio | Identify spoofing patterns |
| **Scatter Plot** | X: Requests_per_IDFA, Y: Impressions_per_IDFA, Legend: IVT_Status | Visualize abnormal device behavior |

---

### **6️⃣ Save the Dashboard**
Go to **File → Save As → IVT_Traffic_Analysis.pbix**  
and store it inside the `PowerBI_Dashboard` folder.

---

## 🧩 Insights to Explore
- Apps marked IVT earlier often show **high IDFA/UA ratio** and **low impression efficiency**.
- Apps marked later may have **gradually increasing requests per IDFA**.
- Non-IVT apps maintain **balanced IP-to-device ratios** and steady engagement.

---

## 🎨 Custom Theme
The dashboard uses a clean professional palette:  
- **Blue (#2E86AB)** for metrics  
- **Green (#43AA8B)** for valid traffic  
- **Red (#F94144)** for IVT  
- **Yellow (#F9C74F)** for warning thresholds

---

## 📦 Deliverables
- `IVT_Traffic_Analysis.pbix` → Power BI report file  
- `IVT_Dashboard_Theme.json` → Custom theme file  
- `README.md` → Documentation for setup and usage  
- `/Data` folder → CSVs (raw data sources)

---

## 🏁 Final Goal
To visualize and understand **traffic anomalies**, detect **fraudulent IVT behavior**, and establish **benchmarks for normal traffic**.

